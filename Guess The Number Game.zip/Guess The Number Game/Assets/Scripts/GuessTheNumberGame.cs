﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GuessTheNumberGame : MonoBehaviour
{
    public InputField input;
    public Text infoText;
    public Text livesText;
    public Button sureButton;
    public Button exit;

    private int guessNumber;
    private int usersGuess;
    private int lives = 10;

    // Start is called before the first frame update
    void Start()
    {
        guessNumber = Random.Range(0, 100);
        livesText.text = "Lives= " + lives;
    }

    //Checking the guess
    public void CheckGuess()
    {
        
        usersGuess = int.Parse(input.text);
        if(usersGuess==guessNumber)
        {
            infoText.text = "You are right Baby doll! :*";
        }else if(usersGuess>guessNumber)
        {
            infoText.text = "You are guessing higher bhaijan!";
            lives--;
        }else if(usersGuess<guessNumber)
        {
            lives--;
            infoText.text = "You are guessing lower chikni!";
        }

        input.text = "";
        livesText.text = "Lives= " + lives;
        if(lives<1)
        {
            infoText.text = "Behenchod guess karna bhi nahi janta!";
            Destroy(sureButton);
            Destroy(input);
            input.text = "Game Over Gandu";
        }
   
    }
    public void Quit()
    {
        Application.Quit();
    }
}
